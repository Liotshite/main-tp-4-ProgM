package org.unh.tp2kotlin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.unh.tp2kotlin.ui.theme.TP2kotlinTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TP2kotlinTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting()
                }
            }
        }
    }
}

@Composable
fun Greeting() {
    Column(modifier = Modifier.padding(15.dp).fillMaxSize()
    ){
        Image(painter = painterResource(id = R.drawable.logo)
            ,modifier = Modifier
            ,contentDescription = "Logo UNH")

        Spacer(modifier = Modifier.border(width = 1.dp, Color.Black.copy(0.5F)))

        Text(text = "Cours de Langage de Programmation Mobile 2", modifier = Modifier, fontSize = 28.sp )

        Spacer(modifier = Modifier.border(width = 1.dp, Color.Blue.copy(0.5F)))


        Text(text = "No Matricule: SI/20201631", modifier = Modifier.padding(bottom = 8.dp), fontSize = 18.sp)
        Text(text = "Nom : TSHITENGE KALEU Lionel", modifier = Modifier.padding(bottom = 8.dp), fontSize = 18.sp)
        Text(text = "Promotion : Master 1",modifier = Modifier.padding(bottom = 8.dp), fontSize = 18.sp)
        Text(text = "Filiere : Genie logiciel",modifier = Modifier.padding(bottom = 8.dp), fontSize = 18.sp)
        Text(text = "Mobile : 0990044005",modifier = Modifier.padding(bottom = 8.dp), fontSize = 18.sp)
        Text(text = "email : tshitengelionel@gmail.com",modifier = Modifier.padding(bottom = 8.dp), fontSize = 18.sp)

    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    TP2kotlinTheme {
        Greeting()
    }
}